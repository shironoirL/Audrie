from __future__ import absolute_import

from .filterset import FilterSet
from .filters import *

VERSION = (0, 2, 0)
__version__ = VERSION  # alias
