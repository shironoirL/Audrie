from _generics.private import private


__all__ = ["private"]
