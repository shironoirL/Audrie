from .base import urlpatterns

__all__ = ["urlpatterns"]
